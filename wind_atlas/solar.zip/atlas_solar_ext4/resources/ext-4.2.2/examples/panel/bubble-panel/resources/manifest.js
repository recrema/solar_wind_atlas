Ext.onReady(function() {
    Ext.manifest = {
        widgets: [
            {
                xtype: 'widget.panel',
                ui: 'bubble'
            },
            {
                xtype: 'widget.header',
                ui: 'bubble'
            }
        ]
    };
});
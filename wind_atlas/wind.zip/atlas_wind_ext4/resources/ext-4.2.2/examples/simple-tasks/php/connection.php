<?php
$db = new PDO('sqlite:../../db/simple_tasks.db');
?>
